package customer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Login {
	WebDriver driver;
	@BeforeMethod
	public void setUp() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\jaipa\\eclipse-workspace\\DG\\chromedriver.exe");
		driver= new ChromeDriver();
		//Thread.sleep(5000);
		driver.manage().window().maximize();		
	}	
    @Test
    public void Test() throws InterruptedException{
    	
    	driver.get("https://automationplayground.com/crm/login.html");
    	driver.findElement(By.xpath("//input[@placeholder='Enter email']")).clear();
    	driver.findElement(By.xpath("//input[@placeholder=Enter email']")).sendKeys("jaipalreddykota40@gmail.com");
    	driver.findElement(By.xpath("//input[@placeholder='Password']")).clear();
    	driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("9290445358");
    	driver.findElement(By.xpath("//table[@id='customers']/thead/tr[1]/th[2]/following::*[text()='Ashley']/following::i[1]")).click();
        String username = driver.findElement(By.xpath("//b[text()='Username:']/following::div")).getText();
        System.out.println(username);
        String address = driver.findElement(By.xpath("//b[text()='Address:']/following::div")).getText();
        System.out.println(address);
        String gender = driver.findElement(By.xpath("//b[text()='Gender:']/following::div")).getText();
        System.out.println(gender);
        driver.findElement(By.xpath("//a[text()='Sign Out']")).click();
     }
		
	 }


